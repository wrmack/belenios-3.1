: ${STABLE_MIRROR:="http://deb.debian.org"}
: ${STABLE_SUITE:="bookworm"}
: ${BACKPORTS_MIRROR:="http://ocaml.debian.net/backports/20250313"}
: ${BACKPORTS_SUITE:="bookworm-backports-ocaml"}
: ${KEYRING:="$(dirname "$0")/ocaml-backports-keyring.asc"}
