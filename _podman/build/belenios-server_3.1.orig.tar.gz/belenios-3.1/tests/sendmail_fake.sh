#!/bin/sh
exec cat >> /tmp/sendmail_fake
