#!/bin/sh
exec cat >> _run/usr/share/belenios-server/mail.txt
